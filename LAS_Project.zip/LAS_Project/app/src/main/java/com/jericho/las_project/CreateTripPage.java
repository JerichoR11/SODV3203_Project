package com.jericho.las_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.time.Year;

public class CreateTripPage extends AppCompatActivity {
    //Initialization
    TextView tv_date;
    Button dateBtn,createTripButton,cancelButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_trip_page);
        tv_date = findViewById(R.id.tv_date);
        dateBtn = findViewById(R.id.btn_add);
        createTripButton = findViewById(R.id.btn_createTrip);
        cancelButton = findViewById(R.id.btn_cancel);
        //both button events go to the home page
        createTripButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent i = new Intent(CreateTripPage.this,HomeScreen.class);
                startActivity(i);
                finish();
            }
        });
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CreateTripPage.this,HomeScreen.class);
                startActivity(i);
                finish();
            }
        });

    }



}