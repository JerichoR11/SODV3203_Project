package com.jericho.las_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class HomeScreen extends AppCompatActivity {
    Intent i;
    Button addTrip;
    ImageButton btnLogout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);
        addTrip = findViewById(R.id.btn_Add_Trip);
        btnLogout = findViewById(R.id.img_btn_log_out);
        addTripPlan(addTrip);
        logoutOfHome(btnLogout);
    }

    //goes to the create trip plan page
    private void addTripPlan(Button addTrip) {
        addTrip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i = new Intent(HomeScreen.this,CreateTripPage.class);
                startActivity(i);
                finish();
            }
        });
    }
    //goes back to the log in page
    private void logoutOfHome(ImageButton logout){
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                i = new Intent(HomeScreen.this,MainActivity.class);
                startActivity(i);
                finish();
            }
        });
    }
}