package com.jericho.las_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CreateAccount extends AppCompatActivity {

    //Initialization
    EditText emailAddress,customerName,customerPassword;
    Button btnCreateAccount;
    TextView tvLoginView;
    User user;
    UserDatabaseHelper utilityDBUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);
        //get the id of certain items in the activity
        btnCreateAccount = findViewById(R.id.btn_register_newAcount);
        emailAddress = findViewById(R.id.et_createEmailAddress);
        customerName = findViewById(R.id.et_CreateName);
        customerPassword = findViewById(R.id.et_createUserPassword);
        tvLoginView = findViewById(R.id.tv_login_view);
        //onclick event to go to login page
        tvLoginView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CreateAccount.this, MainActivity.class);
                startActivity(i);
                finish();

            }
        });
        //onclick event adds user to the database
        btnCreateAccount.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                //need to use in order to use the database
                utilityDBUser = new UserDatabaseHelper(CreateAccount.this);
                //checks if the inputs are empty
                if (emailAddress.getText().toString().equals("") || customerName.getText().toString().equals("") || customerPassword.getText().toString().equals("")) {
                    Toast.makeText(CreateAccount.this, "Please do not enter empty fields", Toast.LENGTH_SHORT).show();
                } else {
                    //try catch to try inserting a user to the table
                    try {
                        //create user object
                        user = new User(emailAddress.getText().toString(), customerName.getText().toString(), customerPassword.getText().toString());
                        //check if insertion of data to the database was successful and will switch to the home page other wise will give a message of not created
                        boolean addedUser = utilityDBUser.addUser(user);
                        if (addedUser == true) {
                            Toast.makeText(CreateAccount.this, "User Created!", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(CreateAccount.this, HomeScreen.class);
                            startActivity(i);
                            finish();

                        } else {
                            Toast.makeText(CreateAccount.this, "User Not Created!", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(CreateAccount.this, e.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });


    }

}