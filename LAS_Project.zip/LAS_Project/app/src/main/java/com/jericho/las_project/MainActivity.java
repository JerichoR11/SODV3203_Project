package com.jericho.las_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button login,registerView;
    EditText email,password;
    Intent logInIntent,activityCreateAccountIntent;
    UserDatabaseHelper utilityDBUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        utilityDBUser = new UserDatabaseHelper(MainActivity.this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = findViewById(R.id.login_btn);
        registerView = findViewById(R.id.btn_registerAccount);
        email = findViewById(R.id.et_textLogin_EmailAddress);
        password = findViewById(R.id.et_textLogin_Password);
        //button event that goes to the home screen
        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                //checks if input is empty
                if (email.getText().toString().equals("") ||  password.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, "Please do not enter empty fields", Toast.LENGTH_SHORT).show();
                }
                else {

                    // logs in the user
                    boolean success = utilityDBUser.CheckAUser(email.getText().toString().trim(),password.getText().toString().trim());
                    if(success == false) {
                        logInIntent= new Intent(MainActivity.this, HomeScreen.class);
                        startActivity(logInIntent);
                    }
                    else{
                        Toast.makeText(MainActivity.this,email.getText().toString()+","+password.getText().toString(),Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });
        //goes to register activity
        registerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activityCreateAccountIntent= new Intent(MainActivity.this,CreateAccount.class);
                startActivity(activityCreateAccountIntent);

            }
        });

    }






}