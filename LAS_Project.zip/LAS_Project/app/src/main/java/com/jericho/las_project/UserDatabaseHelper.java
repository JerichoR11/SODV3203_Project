package com.jericho.las_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

//Database helper to create table and use database functionalities
public class UserDatabaseHelper extends SQLiteOpenHelper {
    //column names
    private static final String USER_TABLE="USER_TABLE";
    private static final String COLUMN_USER_ID="ID";
    private static final String COLUMN_USER_NAME="USER_NAME";
    private static final String COLUMN_EMAIL="USER_EMAIL";
    private static final String COLUMN_PASSWORD="USER_PASSWORD";
    //database creation
    public UserDatabaseHelper(@Nullable Context context) {
        super(context, "user.db", null, 1);
    }

    //created on load
    @Override
    public void onCreate(SQLiteDatabase sqlDB) {
        //sql query to create table
        String createTableStatement = "CREATE TABLE " + USER_TABLE + " (" +  COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_USER_NAME + " TEXT, " + COLUMN_EMAIL + " TEXT, " + COLUMN_PASSWORD + " TEXT)";
        sqlDB.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqlDB, int i, int i1) {
        sqlDB.execSQL("DROP TABLE IF EXISTS "+USER_TABLE);
        onCreate(sqlDB);
    }
    //inserts user login credentials to database table
    public boolean addUser(User newUser) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_USER_NAME, newUser.getUserName());
        cv.put(COLUMN_EMAIL, newUser.getEmail());
        cv.put(COLUMN_PASSWORD, newUser.getPassword());
        long insert = db.insert(USER_TABLE, null, cv);
        //checks to see if insertion
        if (insert == -1) {
            Log.d("Insert Info: ", "DATA INSERTION INCORRECT");
            return false;
        } else {
            Log.d("Insert Info: ", "USER HAS BEEN INSERTED TO " + USER_TABLE);
            return true;
        }
    }
    //checks user from database table
    public boolean CheckAUser(String userEmail, String userPassword) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT *FROM USER_TABLE WHERE USER_EMAIL=? AND USER_PASSWORD=?", new String[]{userEmail,userPassword});
        int count = cursor.getCount();
        //if there is a user return true else return false
        cursor.close();
        db.close();
        if(count >0)
            return true;
        return false;
    }
}